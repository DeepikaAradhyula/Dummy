package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	AccountDao dao=new AccountDaoImpl();
	@Override
	public boolean validateMobileNo(String phoneNo) throws AccountException {
		
		if(!phoneNo.matches("\\d{10}")){
			throw new AccountException("Moblie Number should contain 10 digits");
			
		}
		return true;
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws AccountException {
		
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public boolean validateRechargeAmount(int rechargeAmt) throws AccountException {
		if(rechargeAmt<0){
			throw new AccountException("Please Enter Valid Recharge Amount. Recharge Amount should be greater than zero");
		}
		return true;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount)
			throws AccountException {
		
		return dao.rechargeAccount(mobileNo, rechargeAmount);
	}

}
