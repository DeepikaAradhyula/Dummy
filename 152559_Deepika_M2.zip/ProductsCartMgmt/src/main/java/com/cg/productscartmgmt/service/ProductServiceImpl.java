package com.cg.productscartmgmt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.productscartmgmt.bean.Product;
import com.cg.productscartmgmt.exception.ProductException;
import com.cg.productscartmgmt.repo.IProductRepo;

/**
 * Class Name:ProductServiceImpl
 * 
 * Interface methods:create(),updateProductById(),deleteProductById(),viewAll(),findProductById()
 * 
 * 
 * Author:Deepika
 * Date of Creation:08-August-2018
 * 
 *  Last Date of Modification:08-August-2018
 * 
 * 
 *
 */
@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	private IProductRepo repo;

	@Override
	public Product create(Product p) throws ProductException {
		if (p.getName().isEmpty() || p.getName() == null) {
			throw new ProductException("Employee name cannot be empty");
		} else {
			if (!p.getName().matches("[A-Z][A-Za-z]{3,}")) {
				throw new ProductException("Name should start with capital letter and should contain only alphabets");
			}
		}
		if (p.getPrice() < 0) {
			throw new ProductException("Price should be greater than zero");
		}
		// TODO Auto-generated method stub
		return repo.save(p);
	}

	@Override
	@Transactional
	public Product updateProductById(Product p) throws ProductException {
		if (p.getName().isEmpty() || p.getName() == null) {
			throw new ProductException("Employee name cannot be empty");
		} else {
			if (!p.getName().matches("[A-Z][A-Za-z]{3,}")) {
				throw new ProductException("Name should start with capital letter and should contain only alphabets");
			}
		}
		if (p.getPrice() < 0) {
			throw new ProductException("Price should be greater than zero");
		}

		Product p1 = repo.getOne(p.getId());

		p1.setName(p.getName());
		p1.setModel(p.getModel());
		p1.setPrice(p.getPrice());
		return p1;
	}

	@Override
	public String deleteProductById(String id) throws ProductException {
		// TODO Auto-generated method stub

		Product p = repo.getOne(id);
		if (p == null) {
			throw new ProductException("id does not exists");
		}
		repo.delete(p);
		return "done deleting";
	}

	@Override
	public List<Product> viewAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Product findProductById(String id) throws ProductException {
		// TODO Auto-generated method stub
		return repo.getOne(id);
	}

}
