package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;

public interface AccountService {
	boolean validateMobileNo(String phoneNo)  throws AccountException;
	Account getAccountDetails(String mobileNo) throws AccountException;
	
	boolean validateRechargeAmount(int rechargeAmt) throws AccountException;
	int rechargeAccount(String mobileNo,double rechargeAmount) throws AccountException;
}
