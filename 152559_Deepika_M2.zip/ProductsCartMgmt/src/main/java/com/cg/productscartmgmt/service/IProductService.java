package com.cg.productscartmgmt.service;

import java.util.List;

import com.cg.productscartmgmt.bean.Product;
import com.cg.productscartmgmt.exception.ProductException;

/**
 * Interface Name:IProductService
 * 
 * Interface methods:create(),updateProductById(),deleteProductById(),viewAll(),findProductById()
 * 
 * 
 * Author:Deepika
 * Date of Creation:08-August-2018
 * 
 *  Last Date of Modification:08-August-2018
 * 
 * 
 *
 */


public interface IProductService {
	public Product create(Product p) throws ProductException;

	public Product updateProductById(Product p) throws ProductException;

	public String deleteProductById(String id) throws ProductException;

	public List<Product> viewAll();

	public Product findProductById(String id) throws ProductException;

	
}
