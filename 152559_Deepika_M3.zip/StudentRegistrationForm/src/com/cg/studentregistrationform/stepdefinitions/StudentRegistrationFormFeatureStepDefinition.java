package com.cg.studentregistrationform.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.studentregistrationform.beans.EducationalDetails;
import com.cg.studentregistrationform.beans.PersonalDetails;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StudentRegistrationFormFeatureStepDefinition {
	//Binding variables
	private WebDriver driver;
	private PersonalDetails personalDetails;
	private EducationalDetails educationDetails;

	//It is executed first
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	}

	//Stepdefinitons
	@Given("^User is on Personal Details Page$")
	public void user_is_on_Personal_Details_Page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("D:\\MPT WebPages\\WebPages_Set 3\\PersonalDetails.html");
		personalDetails=PageFactory.initElements(driver, PersonalDetails.class);
		educationDetails=PageFactory.initElements(driver, EducationalDetails.class);

	}

	@When("^User verifies the title of the page$")
	public void user_verifies_the_title_of_the_page() throws Throwable {

	}

	@Then("^'Personal Details' title should be present$")
	public void personal_Details_title_should_be_present() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Personal Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User clicks on 'Next' link without entering 'First Name'$")
	public void user_clicks_on_Next_link_without_entering_First_Name() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setFirstName("Deepika");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'Last Name'$")
	public void user_clicks_on_Next_link_without_entering_Last_Name() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Last Name";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setLastName("Aradhyula");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'Email'$")
	public void user_clicks_on_Next_link_without_entering_Email() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please fill the Email' message should display$")
	public void please_fill_the_Email_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Email";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setEmail("deepika capgemini.com");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link after entering invalid 'Email' address$")
	public void user_clicks_on_Next_link_after_entering_invalid_Email_address() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please enter valid Email Id\\.' message should display$")
	public void please_enter_valid_Email_Id_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Email Id.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setEmail("deepika@capgemini.com");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'Contact No\\.'$")
	public void user_clicks_on_Next_link_without_entering_Contact_No() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please fill the Contact No\\.' message should display$")
	public void please_fill_the_Contact_No_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setContactNo("12345");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link after entering invalid 'Contact No\\.' address$")
	public void user_clicks_on_Next_link_after_entering_invalid_Contact_No_address() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please enter valid Contact no\\.' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Contact no.";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setContactNo("9505928555");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'Address Line (\\d+)'$")
	public void user_clicks_on_Next_link_without_entering_Address_Line(int arg1) throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please fill the address line (\\d+)' message should display$")
	public void please_fill_the_address_line_message_should_display(int arg1) throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the address line 1";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setAddressLine1("allwyn");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'AddressLine(\\d+)'$")
	public void user_clicks_on_Next_link_without_entering_AddressLine(int arg1) throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please fill the addressline(\\d+)' message should display$")
	public void please_fill_the_addressline_message_should_display(int arg1) throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the address line 2";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setAddressLine2("kukatpally");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'City'$")
	public void user_clicks_on_Next_link_without_entering_City() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {


		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select city";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setCity("Bangalore");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link without entering 'State'$")
	public void user_clicks_on_Next_link_without_entering_State() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select state";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		personalDetails.setState("Karnataka");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Next' link after entering valid set of data$")
	public void user_clicks_on_Next_link_after_entering_valid_set_of_data() throws Throwable {
		personalDetails.clickNextLink();
	}

	@Then("^'Personal details are validated and accepted successfully\\.' message should display$")
	public void personal_details_are_validated_and_accepted_successfully_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Personal details are validated and accepted successfully.";
		Assert.assertEquals(expectedMessage, actualMessage);


		Thread.sleep(1000);
	}

	@Then("^navigate to 'educational Details' Page$")
	public void navigate_to_educational_Details_Page() throws Throwable {

		Alert jsAlert = driver.switchTo().alert();
		if(jsAlert.getText().equals("Personal details are validated and accepted successfully."))
		{
			Thread.sleep(1000);
			jsAlert.accept();
			driver.navigate().to("D:\\MPT WebPages\\WebPages_Set 3\\EducationalDetails.html");
			driver.manage().window().maximize();

		}
		else
		{

		}

	}

	@When("^User clicks on 'Register Me' button without selecting 'Graduation'$")
	public void user_clicks_on_Register_Me_button_without_selecting_Graduation() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Please Select Graduation' message should display$")
	public void please_Select_Graduation_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please Select Graduation";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		educationDetails.setGraduation("BTech");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Register Me' button without entering 'Percentage'$")
	public void user_clicks_on_Register_Me_button_without_entering_Percentage() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Please fill Percentage detail' message should display$")
	public void please_fill_Percentage_detail_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill Percentage detail";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		educationDetails.setPercentage("80");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Register Me' button without entering 'Passing Year'$")
	public void user_clicks_on_Register_Me_button_without_entering_Passing_Year() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Please fill Passing Year' message should display$")
	public void please_fill_Passing_Year_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill Passing Year";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		educationDetails.setPassingYear("2018");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Register Me' button without entering 'Project Name'$")
	public void user_clicks_on_Register_Me_button_without_entering_Project_Name() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Please fill Project Name' message should display$")
	public void please_fill_Project_Name_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill Project Name";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		educationDetails.setProjectName("Date Processor");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Register Me' button without selecting 'Technologies Used'$")
	public void user_clicks_on_Register_Me_button_without_selecting_Technologies_Used() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Please Select Technologies Used' message should display$")
	public void please_Select_Technologies_Used_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please Select Technologies Used";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		educationDetails.setTechnologiesUsed(".Net");
		educationDetails.setTechnologiesUsed("Other");
		Thread.sleep(1000);
	}

	@When("^User clicks on 'Register Me' button after selecting 'Other Technology' without entering 'Other Technologies'$")
	public void user_clicks_on_Register_Me_button_after_selecting_Other_Technology_without_entering_Other_Technologies() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Please fill other Technologies Used' message should display$")
	public void please_fill_other_Technologies_Used_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill other Technologies Used";
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		educationDetails.setOtherTechnologies("Python");

		Thread.sleep(1000);
	}

	@When("^User clicks on 'Register Me' button after entering valid set of information$")
	public void user_clicks_on_Register_Me_button_after_entering_valid_set_of_information() throws Throwable {
		educationDetails.clickRegisterMe();
	}

	@Then("^'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!' message should display$")
	public void your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link_message_should_display() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		Assert.assertEquals(expectedMessage, actualMessage);

	}

	@Then("^close the browser window$")
	public void close_the_browser_window() throws Throwable {

		Alert jsAlert = driver.switchTo().alert();
		if(jsAlert.getText().equals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!"))
		{
			driver.close();

		}
		else
		{

		}

	}


}
