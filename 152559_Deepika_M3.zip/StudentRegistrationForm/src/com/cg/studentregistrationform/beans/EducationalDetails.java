package com.cg.studentregistrationform.beans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class EducationalDetails {

	//declaring parameters
	@FindBy(how=How.NAME,name="graduation")
	private WebElement graduation;

	@FindBy(how=How.ID,id="txtPercentage")
	private WebElement percentage;

	@FindBy(how=How.ID,id="txtPassYear")
	private WebElement passingYear;

	@FindBy(how=How.ID,id="txtProjectName")
	private WebElement projectName;

	@FindBy(how=How.NAME,name="technologies")
	private List<WebElement> technologiesUsed;

	@FindBy(how=How.ID,id="txtOtherTechs")
	private WebElement otherTechnologies;

	@FindBy(how=How.ID,id="btnRegister")
	private WebElement register;

	int size=4;
	int i;

	//Getters and setters
	public String getGraduation() {
		return new Select(this.graduation).getFirstSelectedOption().getText();
	}

	public void setGraduation(String graduation) {
		new Select(this.graduation).selectByVisibleText(graduation);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getTechnologiesUsed() {
		for(i=0;i<size;i++) 
			if(technologiesUsed.get(i).isSelected()) 
				return technologiesUsed.get(i).getAttribute("value");
		return null;	
	}

	public void setTechnologiesUsed(String technologiesUsed) {
		if(technologiesUsed.equals(".Net"))
			this.technologiesUsed.get(0).click();
		if(technologiesUsed.equals("Java"))
			this.technologiesUsed.get(1).click();
		if(technologiesUsed.equals("PHP"))
			this.technologiesUsed.get(2).click();
		if(technologiesUsed.equals("Other"))
			this.technologiesUsed.get(3).click();


	}

	public String getOtherTechnologies() {
		return otherTechnologies.getAttribute("value");
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);;
	}


	//button click function
	public void clickRegisterMe() {
		register.click();
	}



}
