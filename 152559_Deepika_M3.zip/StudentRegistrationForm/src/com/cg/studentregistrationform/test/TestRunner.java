package com.cg.studentregistrationform.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = { "Features" }, //folder to be searched
		glue = { "com.cg.studentregistrationform.stepdefinitions" }, //package to search 
		tags = {"@execute" }) //tags to be executed
public class TestRunner {

}
