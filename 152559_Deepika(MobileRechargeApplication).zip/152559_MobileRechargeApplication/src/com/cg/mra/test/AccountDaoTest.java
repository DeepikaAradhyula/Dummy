package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;





import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;

public class AccountDaoTest {
AccountDao dao;
	@Before

	public void init(){
			dao=new AccountDaoImpl();
	}
	
	@Test
	public void testRechargeAccount() throws AccountException {
	
	assertNotNull(dao.getAccountDetails("9505928555"));
	}

}
