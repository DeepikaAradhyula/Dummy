package com.cg.productscartmgmt.exception;

public class ProductException extends Exception {
	public ProductException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public ProductException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
