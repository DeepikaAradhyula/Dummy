package com.cg.productscartmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productscartmgmt.bean.Product;
import com.cg.productscartmgmt.exception.ProductException;
import com.cg.productscartmgmt.service.IProductService;

/**
 * Class Name:ProductController
 * 
 * Interface methods:createp(),updateProductById(),deleteProc(),viewAllProducts(),findProductById()
 * 
 * 
 * Author:Deepika
 * Date of Creation:08-August-2018
 * 
 *  Last Date of Modification:08-August-2018
 * 
 * 
 *
 */
@RestController
public class ProductController {
	@Autowired
	private IProductService service;

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Product createp(@RequestBody Product p) throws ProductException {
		Product p1 = null;
		try {
			
				p1 = service.create(p);
			
		} catch (ProductException e) {
			throw new ProductException(e.getMessage());
		}
		return p1;
	}

	@RequestMapping(value = "/updateproduct", method = RequestMethod.PUT)
	public Product updateProductById(@RequestBody Product p) throws ProductException {
		Product p1 = null;
		try {
			p1 = service.updateProductById(p);
		} catch (ProductException e) {
			throw new ProductException(e.getMessage());
		}
		return p1;
	}

	@RequestMapping(value = "/del", method = RequestMethod.DELETE)
	public String deleteProc(String id) throws ProductException {
		String s = "null";
		try {
			s = service.deleteProductById(id);
		} catch (ProductException e) {
			throw new ProductException(e.getMessage());
		}
		return s;
	}

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public List<Product> viewAllProducts() {
		return service.viewAll();
	}

	@RequestMapping(value = "/productbyid", method = RequestMethod.GET)
	public Product findProductById(String id) throws ProductException {
		Product p1 = null;

		try {
			p1 = service.findProductById(id);
		} catch (ProductException e) {

			throw new ProductException(e.getMessage());
		}
		return p1;
	}
}
