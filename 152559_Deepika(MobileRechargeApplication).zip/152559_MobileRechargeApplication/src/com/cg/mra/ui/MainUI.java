package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	
	Scanner scan=new Scanner(System.in);
	AccountService service=new AccountServiceImpl(); 
	
	public static void main(String[] args) {
		MainUI mainObject=new MainUI();
		String option="";
		while(true){
			System.out.println("Mobile Recharge Application");
			System.out.println("1) Account Balance Enquiry");
			System.out.println("2) Recharge Account");
			System.out.println("3) Exit");
			System.out.println("Enter your choice");
			option=mainObject.scan.nextLine();
			switch(option){
				case "1":
					mainObject.getAccountDetails();
					break;
				case "2":
					mainObject.rechargeAccount();
					break;
				case "3":
					System.exit(0);

			}
			
		}
	}
	
	public void getAccountDetails(){
		
		System.out.print("Enter Mobile No: ");
		String phoneNo=scan.nextLine();
		try {
			boolean result=service.validateMobileNo(phoneNo);
			if(result){
				Account acc=service.getAccountDetails(phoneNo);
				System.out.println();
				System.out.println("Your current balance is Rs. "+acc.getAccountBalance());
				System.out.println();
			}
		} catch (AccountException e) {
			
			System.out.println();
			System.err.println(e.getMessage());
			System.out.println();
		}
		
	}
	public void rechargeAccount(){
		System.out.print("Enter MobileNo: ");
		String phoneNo=scan.nextLine();
		System.out.print("Enter Recharge Amount: ");
		int rechargeAmt=Integer.parseInt((scan.nextLine()));
		try {
			boolean validMobileNo=service.validateMobileNo(phoneNo);
			boolean validRechargeAmt=service.validateRechargeAmount(rechargeAmt);
			if(validMobileNo&&validRechargeAmt){
				
				int availableBalance=service.rechargeAccount(phoneNo, rechargeAmt);
				Account acc=service.getAccountDetails(phoneNo);
				System.out.println();
				System.out.println("Your Account Recharged Successfully");
				System.out.println("Hello "+ acc.getCustomerName()+",Available Balance is "+availableBalance);
				System.out.println();
			}
			
		} catch (AccountException e) {
			System.out.println();
			System.err.println(e.getMessage());
			System.out.println();
			
		}
	}

}
