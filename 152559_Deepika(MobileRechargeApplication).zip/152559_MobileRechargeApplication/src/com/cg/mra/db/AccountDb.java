package com.cg.mra.db;

import java.util.HashMap;

import com.cg.mra.beans.Account;



public class AccountDb {
	private static HashMap<String,Account> accountDb=
			new HashMap<String,Account>();

	
	
	public static HashMap<String, Account> getAccountDb() {
		return accountDb;
	}


	static{
		accountDb.put("9505928555", new Account("9505928555","Idea","Deepika",500.0));
		accountDb.put("9948716746", new Account("9948716746","Idea","NagaRaju",1000.0));
		accountDb.put("9848468242", new Account("9848468242","Vodaphone","HemaLatha",800.0));
		accountDb.put("9701978539", new Account("9701978539","","Airtel",600.0));
	}
}
