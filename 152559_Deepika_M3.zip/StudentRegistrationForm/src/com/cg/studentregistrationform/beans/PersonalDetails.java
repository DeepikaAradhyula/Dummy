package com.cg.studentregistrationform.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class PersonalDetails {

	//declaring parameters
	@FindBy(how=How.ID,id="txtFirstName")
	private WebElement firstName;

	@FindBy(how=How.ID,id="txtLastName")
	private WebElement lastName;

	@FindBy(how=How.ID,id="txtEmail")
	private WebElement email;

	@FindBy(how=How.ID,id="txtPhone")
	private WebElement contactNo;

	@FindBy(how=How.ID,id="txtAddress1")
	private WebElement addressLine1;

	@FindBy(how=How.ID,id="txtAddress2")
	private WebElement addressLine2;

	@FindBy(how=How.NAME,name="city")
	private WebElement city;

	@FindBy(how=How.NAME,name="state")
	private WebElement state;

	@FindBy(how=How.LINK_TEXT,linkText="Next")
	private WebElement nextLink;

	//Getters and Setters
	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public String getContactNo() {
		return contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.clear();
		this.contactNo.sendKeys(contactNo);
	}

	public String getAddressLine1() {
		return addressLine1.getAttribute("value");
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1.sendKeys(addressLine1);
	}

	public String getAddressLine2() {
		return addressLine2.getAttribute("value");
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2.sendKeys(addressLine2);
	}

	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	//Click method for Link
	public void clickNextLink() {
		nextLink.click();
	}



}
