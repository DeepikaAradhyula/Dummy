package com.cg.mra.dao;

import java.util.HashMap;



import com.cg.mra.beans.Account;
import com.cg.mra.db.AccountDb;
import com.cg.mra.exception.AccountException;
/**
 * Class Name: AccountDaoImpl
 * Interface implemented :AccountDao
 * No. of Methods: 2
 * 
 * Name of Methods:getAccountDetails,rechargeAccount
 * Purpose:Display current balance and Available balance
 * 
 * Author:Deepika
 * Date of Creation:11-July-2018
 * 
 *  Last Date of Modification:11-July-2018
 * 
 * 
 *
 */

public class AccountDaoImpl implements AccountDao {
	static HashMap<String,Account> accMap=
			AccountDb.getAccountDb();
	/**
	 * Name of Method:getAccountDetails
	 * Parameter Expected:String Mobile Number
	 * Return type:Account ,acc
	 * Author:Deepika
	 * Date of Creation:11-July-2018
	 * Purpose of Method:Get account details
	 * 
	 * 
	 */

	
	@Override
	public Account getAccountDetails(String mobileNo) throws AccountException {
		
		Account acc=accMap.get(mobileNo);
		if(acc==null){
			throw new AccountException("ERROR: Given Account Id Does Not Exits");
		}
		
		return acc;
	}
	
/**
 * Name of Method:rechargeAccount
 * Parameter Expected:String Mobile Number,double rechargeAmopunt
 * Return type:int,availablebalance
 * Author:Deepika
 * Date of Creation:11-July-2018
 * Purpose of Method:Get updated balance
 * 
 * 
 */


	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws AccountException {
		Account acc=accMap.get(mobileNo);
		if(acc==null){
			throw new AccountException("ERROR: Cannot Recharge Account as Given Mobile No Does Not Exits");
		}
		acc.setAccountBalance(acc.getAccountBalance()+rechargeAmount);
		
		return (int) acc.getAccountBalance();
	}
	
}
