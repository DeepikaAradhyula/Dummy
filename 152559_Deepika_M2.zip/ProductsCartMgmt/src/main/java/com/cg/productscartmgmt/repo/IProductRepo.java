package com.cg.productscartmgmt.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.productscartmgmt.bean.Product;


/**
 * Interface Name:IProductRepo
 * 
 * 
 * 
 * 
 * Author:Deepika
 * Date of Creation:08-August-2018
 * 
 *  Last Date of Modification:08-August-2018
 * 
 * 
 *
 */

@Repository
public interface IProductRepo extends JpaRepository<Product, String> {

}
